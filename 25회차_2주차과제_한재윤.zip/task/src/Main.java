//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int score = 85;
        // intscore = 93

        //1. score가 85면 출력조건
        // 점수가90보다작습니다.
        // 등급은B입니다
        if  (score <= 90) {
            System.out.println("점수가 90보다 작습니다.");
            System.out.println("등급은 B입니다.");
        }

        //2. score가 93 이면 출력조건
        // 점수가90보다큽니다.
        // 등급은A입니다.
        else{
            System.out.println("점수가 90보다 큽니다.");
            System.out.println("등급은 A입니다.");
        }

    }
}