package task_260415;
/*
* for문을사용하여다음과같이출력하세요
* 출력
* 1 2 3 4 5 6 7 8 9 10
* */
public class PrintFrom1To10Example {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.print(i + " ");
        }
    }
}
